import pandas as pd
pd.options.display.float_format = '${:,.2f}'.format
fields = ["Department", "2012 Actual"]
df = pd.read_csv('city-of-seattle-2012-expenditures-dollars.csv', skipinitialspace=True, usecols=fields)
dataframe = pd.DataFrame(df, columns=['Department', '2012 Actual'])
df_sum = dataframe.groupby('Department').sum()


print(df_sum)
